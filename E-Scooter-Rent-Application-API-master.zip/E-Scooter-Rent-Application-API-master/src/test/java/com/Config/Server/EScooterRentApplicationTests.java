package com.Config.Server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EScooterRentApplicationTests {

	@Test
	void contextLoads() {
	}

}
